import sys
import os
from datetime import datetime
import customtkinter as ctk
from CTkTable import CTkTable
import pandas as pd
from PIL import Image

# PyInstaller creates a temp folder and stores path in _MEIPASS requires this to obtain absolute PATH


def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class ToolTracer(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.configure(fg_color="#5DBA1F")
        self.title("Tool Tracer")
        self.iconbitmap(resource_path("assets/images/tap.ico"))
        self.geometry('1400x800')
        self.attributes("-fullscreen", True)
        self.bind("<Escape>", lambda event: self.attributes(
            "-fullscreen", False))
        self.bind("<F11>", lambda event: self.attributes(
            "-fullscreen", True))

        # Load databases
        self.df_partlist = pd.read_csv(resource_path(
            "assets/data/DEFLOC_REPORT.csv"), encoding='utf-8-sig').astype(str)
        self.df_employee = pd.read_csv(resource_path(
            "assets/data/employee.csv"), encoding='utf-8-sig').astype(str)

        # Scanner input and background image
        self.current_scan = ""
        self.bg_main_image = Image.open(
            resource_path("assets/images/bg_main.PNG"))
        self.background_main = ctk.CTkImage(
            light_image=self.bg_main_image, dark_image=self.bg_main_image, size=(1280, 720))

        # Global variables for operations
        self.user_id = ""
        self.checkin_list = []
        self.checkout_list = []
        self.partheld_table = None
        self.outsidestorage_table = None
        self.logout_timer_id = None
        self.is_on_op_select_frame = False

        # Bind barcode scanner (acts as keyboard input)
        self.bind("<Key>", self.id_scan_keypress)

        # ---------------------------------------------------------
        # Frame 1: Start Frame
        # ---------------------------------------------------------
        self.start_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")
        self.start_frame.pack(padx=10, pady=10, expand=True, fill="both")

        self.start_frame_bg = ctk.CTkLabel(
            self.start_frame, image=self.background_main, text="")
        self.start_frame_bg.pack(fill="both", expand=True)
        self.bind("<Configure>", lambda e: self.resize_bg(e, self.start_frame))

        self.id_label = ctk.CTkButton(self.start_frame, text="Scan Your ID Card", font=("Verdana", 24, "bold"),
                                      corner_radius=0, border_width=5, border_color="#000000", state="disabled",
                                      text_color_disabled="#FFFFFF", bg_color="#000000", fg_color="#5DBA1F")
        self.id_label.place(rely=0.5, relx=0.855, relwidth=0.25,
                            relheight=0.15, anchor="center")

        ctk.CTkButton(self.start_frame, text="Parts Outside Storage", font=("Verdana", 24, "bold"), corner_radius=0,
                      border_width=5, border_color="#000000", state="disabled", text_color_disabled="#000000",
                      bg_color="#000000", fg_color="#9DA39C").place(rely=0.355, relx=0.06, relwidth=0.55, relheight=0.15, anchor="sw")

        self.outsidestorage_scrollframe = ctk.CTkScrollableFrame(self.start_frame, corner_radius=0, border_width=6,
                                                                 border_color="#000000", bg_color="#000000",
                                                                 fg_color="#9DA39C", scrollbar_fg_color="#000000")
        self.outsidestorage_scrollframe.place(
            relx=0.06, rely=0.35, relwidth=0.55, relheight=0.55, anchor="nw")

        self.fill_outsidestorage_table()

        # ---------------------------------------------------------
        # Frame 2: Operation Selection Frame
        # ---------------------------------------------------------
        self.op_select_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")
        ctk.CTkLabel(self.op_select_frame, image=self.background_main,
                     text="").pack(fill="both", expand=True)

        ctk.CTkLabel(self.op_select_frame, text="Select Operation:", font=("Verdana", 24, "bold"), text_color="#000000",
                     corner_radius=0, bg_color="#5DBA1F", fg_color="#5DBA1F").place(relx=0.33, rely=0.8, relheight=0.15, relwidth=0.2, anchor="s")

        self.sel_checkin_button = ctk.CTkButton(self.op_select_frame, text="Check-In", font=("Verdana", 24, "bold"),
                                                text_color="#FFFFFF", border_width=5, corner_radius=10,
                                                bg_color="#5DBA1F", fg_color="#4C961A", hover_color="#5AA826", border_color="#000000", command=self.sel_checkin)
        self.sel_checkin_button.place(
            rely=0.8, relx=0.07, relwidth=0.2, relheight=0.15, anchor="nw")

        self.sel_checkout_button = ctk.CTkButton(self.op_select_frame, text="Check-Out", font=("Verdana", 24, "bold"),
                                                 text_color="#FFFFFF", border_width=5, corner_radius=10,
                                                 bg_color="#5DBA1F", fg_color="#4C961A", hover_color="#5AA826", border_color="#000000", command=self.sel_checkout)
        self.sel_checkout_button.place(
            rely=0.8, relx=0.6, relwidth=0.2, relheight=0.15, anchor="ne")

        self.sel_logout_button = ctk.CTkButton(self.op_select_frame, text="Logout", font=("Verdana", 24, "bold"),
                                               text_color="#FFFFFF", width=200, height=70, border_width=5, corner_radius=0,
                                               bg_color="#000000", fg_color="#8D250B", hover_color="#83260F", border_color="#000000", command=self.logout_op)
        self.sel_logout_button.place(
            rely=0.5, relx=0.855, relwidth=0.2, relheight=0.15, anchor="center")

        ctk.CTkButton(self.op_select_frame, text="Parts Held by User", font=("Verdana", 24, "bold"), corner_radius=0, border_width=5,
                      border_color="#000000", state="disabled", text_color_disabled="#000000", bg_color="#000000", fg_color="#9DA39C").place(rely=0.315, relx=0.06, relwidth=0.55, relheight=0.15, anchor="sw")

        self.partheld_scrollframe = ctk.CTkScrollableFrame(self.op_select_frame, corner_radius=0, border_width=6,
                                                           border_color="#000000", bg_color="#000000", fg_color="#9DA39C", scrollbar_fg_color="#000000")
        self.partheld_scrollframe.place(
            relx=0.06, rely=0.31, relwidth=0.55, relheight=0.35, anchor="nw")

        self.user_id_label = ctk.CTkLabel(self.op_select_frame, text="", font=("Verdana", 24, "bold"), text_color="#000000",
                                          corner_radius=0, bg_color="#5DBA1F", fg_color="#5DBA1F", anchor="w")
        self.user_id_label.place(relx=0.06, rely=0.025,
                                 relheight=0.14, relwidth=0.35, anchor="nw")

        # ---------------------------------------------------------
        # Frame 3: Check-In Operation Frame
        # ---------------------------------------------------------
        self.checkin_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")

        self.checkin_scrollframe = ctk.CTkScrollableFrame(self.checkin_frame, corner_radius=0, border_width=5,
                                                          border_color="#000000", bg_color="#FFFFFF", fg_color="#9DA39C", scrollbar_fg_color="#000000")
        self.checkin_scrollframe.place(
            relx=0.05, rely=0.25, relwidth=0.5, relheight=0.7)

        ctk.CTkButton(self.checkin_frame, corner_radius=0, border_width=4, border_color="#000000", bg_color="#FFFFFF", fg_color="#9DA39C",
                      state="disabled", text="Check-In Cart", font=("Verdana", 26, "bold"), text_color_disabled="#000000").place(relx=0.05, rely=0.05, relheight=0.1, relwidth=0.3)

        ctk.CTkLabel(self.checkin_frame, text="Scan Your Part:", font=("Verdana", 26, "bold"), text_color="#000000",
                     justify="left", anchor="w").place(relx=0.05, rely=0.15, relheight=0.1, relwidth=0.20)

        self.checkin_statuslabel = ctk.CTkLabel(self.checkin_frame, text="", font=(
            "Verdana", 26, "bold"), text_color="#000000", justify="left", anchor="w")
        self.checkin_statuslabel.place(
            relx=0.25, rely=0.15, relheight=0.1, relwidth=0.30)

        ctk.CTkButton(self.checkin_frame, text="Complete Check-In", font=("Verdana", 26, "bold"), text_color="#FFFFFF", border_width=10,
                      corner_radius=20, bg_color="#FFFFFF", fg_color="#5DBA1F", hover_color="#5AA826", border_color="#000000", command=self.complete_checkin).place(relx=0.65, rely=0.25, relheight=0.2, relwidth=0.3)

        ctk.CTkButton(self.checkin_frame, text="Add All Held Tools", font=("Verdana", 26, "bold"), text_color="#FFFFFF", border_width=10,
                      corner_radius=20, bg_color="#FFFFFF", fg_color="#4C961A", hover_color="#5AA826", border_color="#000000", command=self.add_all_held_parts).place(relx=0.65, rely=0.5, relheight=0.2, relwidth=0.3)

        ctk.CTkButton(self.checkin_frame, text="Cancel Operation", font=("Verdana", 26, "bold"), text_color="#000000", border_width=10,
                      corner_radius=20, bg_color="#FFFFFF", fg_color="#697767", hover_color="#71996B", border_color="#000000", command=self.cancel_checkin).place(relx=0.65, rely=0.75, relheight=0.2, relwidth=0.3)

        # ---------------------------------------------------------
        # Frame 4: Check-Out Operation Frame
        # ---------------------------------------------------------
        self.checkout_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")

        self.checkout_scrollframe = ctk.CTkScrollableFrame(self.checkout_frame, corner_radius=0, border_width=4,
                                                           border_color="#000000", bg_color="#FFFFFF", fg_color="#9DA39C", scrollbar_fg_color="#000000")
        self.checkout_scrollframe.place(
            relx=0.05, rely=0.25, relwidth=0.5, relheight=0.7)

        ctk.CTkButton(self.checkout_frame, corner_radius=0, border_width=4, border_color="#000000", bg_color="#FFFFFF", fg_color="#9DA39C",
                      state="disabled", text="Check-Out Cart", font=("Verdana", 26, "bold"), text_color_disabled="#000000").place(relx=0.05, rely=0.05, relheight=0.1, relwidth=0.3)

        ctk.CTkLabel(self.checkout_frame, text="Scan Your Part:", font=("Verdana", 26, "bold"), text_color="#000000",
                     justify="left", anchor="w").place(relx=0.05, rely=0.15, relheight=0.1, relwidth=0.20)

        self.checkout_statuslabel = ctk.CTkLabel(self.checkout_frame, text="", font=(
            "Verdana", 26, "bold"), text_color="#000000", justify="left", anchor="w")
        self.checkout_statuslabel.place(
            relx=0.25, rely=0.15, relheight=0.1, relwidth=0.30)

        ctk.CTkButton(self.checkout_frame, text="Complete Check-Out", font=("Verdana", 26, "bold"), text_color="#FFFFFF", border_width=10,
                      corner_radius=20, bg_color="#FFFFFF", fg_color="#5DBA1F", hover_color="#5AA826", border_color="#000000", command=self.complete_checkout).place(relx=0.65, rely=0.25, relheight=0.2, relwidth=0.3)

        ctk.CTkButton(self.checkout_frame, text="Cancel Operation", font=("Verdana", 26, "bold"), text_color="#000000", border_width=10,
                      corner_radius=20, bg_color="#FFFFFF", fg_color="#697767", hover_color="#71996B", border_color="#000000", command=self.cancel_checkout).place(relx=0.65, rely=0.75, relheight=0.2, relwidth=0.3)

        # ---------------------------------------------------------
        # Frames 5 & 6: End Operation Frames
        # ---------------------------------------------------------
        self.checkin_over_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")
        ctk.CTkLabel(self.checkin_over_frame, text="Check-In Completed", font=("Verdana",
                     36, "bold"), text_color="#000000").place(relx=0.5, rely=0.5, anchor="center")

        self.checkout_over_frame = ctk.CTkFrame(
            self, corner_radius=20, bg_color="#5DBA1F", fg_color="#FFFFFF")
        ctk.CTkLabel(self.checkout_over_frame, text="Check-Out Completed", font=("Verdana",
                     36, "bold"), text_color="#000000").place(relx=0.5, rely=0.5, anchor="center")

    # =========================================================
    # Utility Functions
    # =========================================================

    def resize_bg(self, event, frame):
        if event.widget == frame:
            self.background_main.configure(size=(event.width, event.height))

    def clear_failure(self):
        self.id_label.configure(text="Scan Your ID Card",
                                bg_color="#000000", fg_color="#5DBA1F")

    def clear_checkin_label(self):
        self.checkin_statuslabel.configure(text="")

    def clear_checkout_label(self):
        self.checkout_statuslabel.configure(text="")

    # =========================================================
    # Scanner Handlers
    # =========================================================

    def id_scan_keypress(self, event):
        if self.start_frame.winfo_manager() != "":
            if event.keysym == 'Return':
                self.verify_id(self.current_scan)
                self.current_scan = ""
            elif len(event.char) == 1:
                self.current_scan += event.char

    def part_scan_checkin(self, event):
        if self.checkin_frame.winfo_manager() != "":
            if event.keysym == 'Return':
                if self.current_scan == "COMPLETE":
                    self.complete_checkin()
                    self.current_scan = ""
                elif self.current_scan == "ADDALL":
                    self.add_all_held_parts()
                    self.current_scan = ""
                elif self.current_scan == "CANCEL":
                    self.cancel_checkin()
                    self.current_scan = ""
                else:
                    if self.current_scan.startswith("RO"):
                        self.current_scan = self.current_scan[2:]
                    self.cart_checkin(self.current_scan)
                    self.current_scan = ""
            elif len(event.char) == 1:
                self.current_scan += event.char

    def part_scan_checkout(self, event):
        if self.checkout_frame.winfo_manager() != "":
            if event.keysym == 'Return':
                if self.current_scan == "COMPLETE":
                    self.complete_checkout()
                    self.current_scan = ""
                elif self.current_scan == "CANCEL":
                    self.cancel_checkout()
                    self.current_scan = ""
                else:
                    if self.current_scan.startswith("RO"):
                        self.current_scan = self.current_scan[2:]
                    self.cart_checkout(self.current_scan)
                    self.current_scan = ""
            elif len(event.char) == 1:
                self.current_scan += event.char

    def op_selection_barcode(self, event):
        if self.op_select_frame.winfo_manager() != "":
            if event.keysym == 'Return':
                if self.current_scan == "CHECKIN":
                    self.sel_checkin()
                    self.current_scan = ""
                elif self.current_scan == "CHECKOUT":
                    self.sel_checkout()
                    self.current_scan = ""
                elif self.current_scan == "LOGOUT":
                    self.logout_op()
                    self.current_scan = ""
                else:
                    self.current_scan = ""
            elif len(event.char) == 1:
                self.current_scan += event.char

    # =========================================================
    # Application Logic
    # =========================================================

    def verify_id(self, scan_id):
        if scan_id in self.df_employee["employee_id"].values:
            self.user_id = scan_id
            self.fill_partheld_table()
            self.start_op()
        else:
            self.id_label.configure(
                text="Invalid ID Card", bg_color="#000000", fg_color="#8D250B")
            self.after(1500, self.clear_failure)

    def cart_checkin(self, scan_part):
        if scan_part in self.df_partlist["psn"].values and self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "INOUT"].values == "in":
            self.checkin_statuslabel.configure(
                text="Part already in storage", text_color="#8D250B")
        elif scan_part in self.checkin_list:
            self.checkin_statuslabel.configure(
                text="Part already in cart", text_color="#8D250B")
        elif scan_part in self.df_partlist["psn"].values:
            self.checkin_statuslabel.configure(
                text="Part added to cart", text_color="#000000")

            part_name = str(
                self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "description"].item())
            part_location = str(
                self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "currlocation"].item())

            item_frame = ctk.CTkFrame(
                self.checkin_scrollframe, fg_color="transparent")
            item_frame.pack(side="top", fill="x", pady=2)

            ctk.CTkButton(item_frame, text="X", width=30, fg_color="#8D250B", hover_color="#83260F",
                          command=lambda p=scan_part, f=item_frame: self.remove_from_checkin_cart(p, f)).pack(side="right", padx=5, anchor="ne")
            cart_label = ctk.CTkLabel(item_frame, font=("Verdana", 20, "bold"), text_color="#000000",
                                      text=f"{part_name} - RO{scan_part} - {part_location}", justify="left", anchor="w")
            cart_label.pack(side="left", padx=5, fill="x", expand=True)
            item_frame.bind("<Configure>", lambda event, lbl=cart_label: lbl.configure(
                wraplength=max(50, event.width - 80)))

            self.checkin_list.append(scan_part)
        else:
            self.checkin_statuslabel.configure(
                text="Part not found", text_color="#8D250B")

        self.after(1500, self.clear_checkin_label)

    def cart_checkout(self, scan_part):
        if scan_part in self.df_partlist["psn"].values and self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "INOUT"].values == "out":
            self.checkout_statuslabel.configure(
                text="Part already in use", text_color="#8D250B")
        elif scan_part in self.checkout_list:
            self.checkout_statuslabel.configure(
                text="Part already in cart", text_color="#8D250B")
        elif scan_part in self.df_partlist["psn"].values:
            self.checkout_statuslabel.configure(
                text="Part added to cart", text_color="#000000")

            part_name = str(
                self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "description"].item())
            part_location = str(
                self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "currlocation"].item())

            item_frame = ctk.CTkFrame(
                self.checkout_scrollframe, fg_color="transparent")
            item_frame.pack(side="top", fill="x", pady=2)

            ctk.CTkButton(item_frame, text="X", width=30, fg_color="#8D250B", hover_color="#83260F",
                          command=lambda p=scan_part, f=item_frame: self.remove_from_checkout_cart(p, f)).pack(side="right", padx=5, anchor="ne")
            cart_label = ctk.CTkLabel(item_frame, font=("Verdana", 20, "bold"), text_color="#000000",
                                      text=f"{part_name} - RO{scan_part} - {part_location}", justify="left", anchor="w")
            cart_label.pack(side="left", padx=5, fill="x", expand=True)
            item_frame.bind("<Configure>", lambda event, lbl=cart_label: lbl.configure(
                wraplength=max(50, event.width - 80)))

            self.checkout_list.append(scan_part)
        else:
            self.checkout_statuslabel.configure(
                text="Part not found", text_color="#8D250B")

        self.after(1500, self.clear_checkout_label)

    # =============================================================
    # Function to remove items from Check-in and Check-Out Carts
    # =============================================================
    def remove_from_checkin_cart(self, part_id, frame_widget):
        if part_id in self.checkin_list:
            self.checkin_list.remove(part_id)
        frame_widget.destroy()
        self.checkin_statuslabel.configure(
            text="Part removed", text_color="#8D250B")
        self.after(1500, self.clear_checkin_label)

    def remove_from_checkout_cart(self, part_id, frame_widget):
        if part_id in self.checkout_list:
            self.checkout_list.remove(part_id)
        frame_widget.destroy()
        self.checkout_statuslabel.configure(
            text="Part removed", text_color="#8D250B")
        self.after(1500, self.clear_checkout_label)

    # =========================================================
    # Navigation & State Management
    # =========================================================

    def start_op(self):
        self.unbind("<Key>")
        self.bind("<Key>", self.op_selection_barcode)
        self.unbind("<Configure>")
        self.bind("<Configure>", lambda e: self.resize_bg(
            e, self.op_select_frame))
        self.start_frame.pack_forget()
        self.user_id_label.configure(text=f"User ID: {self.user_id}")
        self.op_select_frame.pack(padx=10, pady=10, expand=True, fill="both")
        self.is_on_op_select_frame = True
        self.bind("<Motion>", self.reset_logout_timer)
        self.bind("<Button-1>", self.reset_logout_timer)
        self.reset_logout_timer()

    def logout_op(self):
        if not getattr(self, 'is_on_op_select_frame', False):
            return

        self.stop_logout_timer()
        self.op_select_frame.pack_forget()
        self.bind("<Key>", self.id_scan_keypress)
        self.unbind("<Configure>")
        self.bind("<Configure>", lambda e: self.resize_bg(e, self.start_frame))
        self.start_frame.pack(padx=10, pady=10, expand=True, fill="both")
        self.user_id = ""
        self.fill_outsidestorage_table()

    def sel_checkin(self):
        self.stop_logout_timer()
        self.unbind("<Key>")
        self.unbind("<Configure>")
        self.op_select_frame.pack_forget()
        self.bind("<Key>", self.part_scan_checkin)
        self.checkin_frame.pack(padx=10, pady=10, expand=True, fill="both")

    def sel_checkout(self):
        self.stop_logout_timer()
        self.unbind("<Key>")
        self.unbind("<Configure>")
        self.op_select_frame.pack_forget()
        self.bind("<Key>", self.part_scan_checkout)
        self.checkout_frame.pack(padx=10, pady=10, expand=True, fill="both")

    def cancel_checkin(self):
        self.fill_partheld_table()
        self.unbind("<Key>")
        self.bind("<Key>", self.op_selection_barcode)
        self.checkin_frame.pack_forget()
        self.checkin_over_frame.pack_forget()
        self.bind("<Configure>", lambda e: self.resize_bg(
            e, self.op_select_frame))
        self.op_select_frame.pack(padx=10, pady=10, expand=True, fill="both")
        self.checkin_list = []
        for widget in self.checkin_scrollframe.winfo_children():
            widget.destroy()

        self.is_on_op_select_frame = True
        self.bind("<Motion>", self.reset_logout_timer)
        self.bind("<Button-1>", self.reset_logout_timer)
        self.reset_logout_timer()

    def cancel_checkout(self):
        self.fill_partheld_table()
        self.unbind("<Key>")
        self.bind("<Key>", self.op_selection_barcode)
        self.checkout_frame.pack_forget()
        self.checkout_over_frame.pack_forget()
        self.bind("<Configure>", lambda e: self.resize_bg(
            e, self.op_select_frame))
        self.op_select_frame.pack(padx=10, pady=10, expand=True, fill="both")
        self.checkout_list = []
        for widget in self.checkout_scrollframe.winfo_children():
            widget.destroy()

        self.is_on_op_select_frame = True
        self.bind("<Motion>", self.reset_logout_timer)
        self.bind("<Button-1>", self.reset_logout_timer)
        self.reset_logout_timer()

    def complete_checkin(self):
        if not self.checkin_list:
            self.checkin_statuslabel.configure(
                text="Cart is Empty", text_color="#8D250B")
            self.after(1500, self.clear_checkin_label)
        else:
            op_date = datetime.now().strftime("%Y-%m-%d")
            op_time = datetime.now().strftime("%H:%M:%S")
            for part in self.checkin_list:
                self.df_partlist.loc[self.df_partlist["psn"]
                                     == part, "INOUT"] = "in"
                self.df_partlist.loc[self.df_partlist["psn"] == part,
                                     "currholder"] = self.df_partlist["currlocation"]

                new_row = pd.DataFrame({'action_type': ['checkin'], 'employee_id': [
                                       self.user_id], 'psn': [part], 'day_stamp': [op_date], 'time_stamp': [op_time]})

                new_row.to_csv(resource_path('assets/data/report_transaction_time.csv'),
                               mode='a', index=False, header=False, encoding='utf-8-sig')

            self.df_partlist.to_csv(resource_path(
                "assets/data/DEFLOC_REPORT.csv"), index=False, encoding='utf-8-sig')
            self.checkin_end()

    def complete_checkout(self):
        if not self.checkout_list:
            self.checkout_statuslabel.configure(
                text="Cart is Empty", text_color="#8D250B")
            self.after(1500, self.clear_checkout_label)
        else:
            op_date = datetime.now().strftime("%Y-%m-%d")
            op_time = datetime.now().strftime("%H:%M:%S")
            for part in self.checkout_list:
                self.df_partlist.loc[self.df_partlist["psn"]
                                     == part, "INOUT"] = "out"
                self.df_partlist.loc[self.df_partlist["psn"]
                                     == part, "currholder"] = self.user_id

                new_row = pd.DataFrame({'action_type': ['checkout'], 'employee_id': [
                                       self.user_id], 'psn': [part], 'day_stamp': [op_date], 'time_stamp': [op_time]})

                new_row.to_csv(resource_path('assets/data/report_transaction_time.csv'),
                               mode='a', index=False, header=False, encoding='utf-8-sig')

            self.df_partlist.to_csv(resource_path(
                "assets/data/DEFLOC_REPORT.csv"), index=False, encoding='utf-8-sig')
            self.checkout_end()

    def checkin_end(self):
        self.unbind("<Key>")
        self.checkin_frame.pack_forget()
        self.checkin_over_frame.pack(
            padx=10, pady=10, expand=True, fill="both")
        self.fill_partheld_table()
        self.after(1500, self.cancel_checkin)

    def checkout_end(self):
        self.unbind("<Key>")
        self.checkout_frame.pack_forget()
        self.checkout_over_frame.pack(
            padx=10, pady=10, expand=True, fill="both")
        self.fill_partheld_table()
        self.after(1500, self.cancel_checkout)

    # =========================================================
    # Function to add all tools held by user to checkin list
    # =========================================================
    def add_all_held_parts(self):
        # Fetch all parts where the current holder is the active user
        held_parts = self.df_partlist.loc[self.df_partlist["currholder"]
                                          == self.user_id, "psn"].values.tolist()
        added_any = False

        for scan_part in held_parts:
            # Avoid duplicating parts already inside the checkin cart display list
            if scan_part not in self.checkin_list:
                part_name = str(
                    self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "description"].item())
                part_location = str(
                    self.df_partlist.loc[self.df_partlist["psn"] == scan_part, "currlocation"].item())

                item_frame = ctk.CTkFrame(
                    self.checkin_scrollframe, fg_color="transparent")
                item_frame.pack(side="top", fill="x", pady=2)

                ctk.CTkButton(item_frame, text="X", width=30, fg_color="#8D250B", hover_color="#83260F",
                              command=lambda p=scan_part, f=item_frame: self.remove_from_checkin_cart(p, f)).pack(side="right", padx=5, anchor="ne")
                cart_label = ctk.CTkLabel(item_frame, font=("Verdana", 20, "bold"), text_color="#000000",
                                          text=f"{part_name} - RO{scan_part} - {part_location}", wraplength=650, justify="left", anchor="w")
                cart_label.pack(side="left", padx=5, fill="x", expand=True)
                item_frame.bind("<Configure>", lambda event, lbl=cart_label: lbl.configure(
                    wraplength=max(50, event.width - 80)))
                self.checkin_list.append(scan_part)
                added_any = True

        if added_any:
            self.checkin_statuslabel.configure(
                text="All held tools added", text_color="#000000")
        else:
            self.checkin_statuslabel.configure(
                text="No tools to add", text_color="#8D250B")

        self.after(1500, self.clear_checkin_label)

    # =========================================================
    # Tables Initialization
    # =========================================================

    def fill_outsidestorage_table(self):
        if self.outsidestorage_table:
            self.outsidestorage_table.destroy()

        headers = ["Description", "Part Number", "PSN", "Part Holder"]
        values = self.df_partlist.loc[self.df_partlist["INOUT"] == "out", [
            "description", "partno", "psn", "currholder"]].values.tolist()
        data = [headers] + values

        self.outsidestorage_table = CTkTable(master=self.outsidestorage_scrollframe, values=data, corner_radius=0,
                                             colors=["#737773", "#8E928D"], text_color="#000000", border_color="#000000",
                                             header_color="#534C4C", font=("Verdana", 16))
        self.outsidestorage_table.edit_row(
            0, font=("Verdana", 18, "bold"), text_color="#000000")
        self.outsidestorage_table.pack(expand=True, fill="both")

    def fill_partheld_table(self):
        if self.partheld_table:
            self.partheld_table.destroy()

        headers = ["Description", "Part Number", "PSN", "Storage Location"]
        values = self.df_partlist.loc[self.df_partlist["currholder"] == self.user_id, [
            "description", "partno", "psn", "currlocation"]].values.tolist()
        data = [headers] + values

        self.partheld_table = CTkTable(master=self.partheld_scrollframe, values=data, corner_radius=0,
                                       colors=["#737773", "#8E928D"], text_color="#000000", border_color="#000000",
                                       header_color="#534C4C", font=("Verdana", 16))
        self.partheld_table.edit_row(
            0, font=("Verdana", 18, "bold"), text_color="#000000")
        self.partheld_table.pack(expand=True, fill="both")

    # =========================================================
    # Logout Timer Logic
    # =========================================================
    def reset_logout_timer(self, event=None):
        """Resets the countdown whenever user activity is caught."""
        # Safety Guard: If we are not explicitly on the selection frame, do nothing
        if not getattr(self, 'is_on_op_select_frame', False):
            return

        if self.logout_timer_id is not None:
            self.after_cancel(self.logout_timer_id)

        self.logout_timer_id = self.after(20000, self.logout_op)

    def stop_logout_timer(self):
        """Cancels pending logouts and sets the tracking flag to False."""
        self.is_on_op_select_frame = False
        if self.logout_timer_id is not None:
            self.after_cancel(self.logout_timer_id)
            self.logout_timer_id = None
        self.unbind("<Motion>")
        self.unbind("<Button-1>")


if __name__ == "__main__":
    app = ToolTracer()
    app.mainloop()
